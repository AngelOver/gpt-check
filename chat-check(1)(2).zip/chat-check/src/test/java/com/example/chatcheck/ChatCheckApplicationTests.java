package com.example.chatcheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatCheckApplicationTests {

    @Test
    void contextLoads() {
    }

}
