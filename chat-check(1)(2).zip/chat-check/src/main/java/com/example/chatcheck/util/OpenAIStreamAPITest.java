package com.example.chatcheck.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class OpenAIStreamAPITest {



//    public static void main(String[] args) {
//        String apiKey = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ik1UaEVOVUpHTkVNMVFURTRNMEZCTWpkQ05UZzVNRFUxUlRVd1FVSkRNRU13UmtGRVFrRXpSZyJ9.eyJodHRwczovL2FwaS5vcGVuYWkuY29tL3Byb2ZpbGUiOnsiZW1haWwiOiJxYTEyNDMwNzY0NDZAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWV9LCJodHRwczovL2FwaS5vcGVuYWkuY29tL2F1dGgiOnsidXNlcl9pZCI6InVzZXIteE5yVEMxMjc5MWtUMVNXYlhYVGJHdlc1In0sImlzcyI6Imh0dHBzOi8vYXV0aDAub3BlbmFpLmNvbS8iLCJzdWIiOiJnb29nbGUtb2F1dGgyfDEwMzk1NzY1NjcxNDQwODE2NzgxNiIsImF1ZCI6WyJodHRwczovL2FwaS5vcGVuYWkuY29tL3YxIiwiaHR0cHM6Ly9vcGVuYWkub3BlbmFpLmF1dGgwYXBwLmNvbS91c2VyaW5mbyJdLCJpYXQiOjE2ODE0NDE4ODQsImV4cCI6MTY4MjY1MTQ4NCwiYXpwIjoiVGRKSWNiZTE2V29USHROOTVueXl3aDVFNHlPbzZJdEciLCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIG1vZGVsLnJlYWQgbW9kZWwucmVxdWVzdCBvcmdhbml6YXRpb24ucmVhZCBvZmZsaW5lX2FjY2VzcyJ9.TFcxSgeAYjalWPfHT-wz9s3GsAo26FSqGUdfI7W4xQkLsVH1VQcahg8XACZzEEAww05YKUbNE2Xv9VYwnn8zHz2aNe0YyWXFMtnhgq7x2Zi8LPgjNSA-CqbiBL5_itQ7_1Qa9l0zvTpXLwTI_qoUVo4WLiSkGEbYKlOZUEtqgeY1zu1rI0ZKqR3gEAPsuiP8GWmSZ-Q4WyTvNSeUOlcgpyqMhUEkG0EQc6804WWHeiJiHAG7HJ51wfBBmWKIH2wZlbEHEm2mrhonhPlRNWvomWCR8LmX5yVnk_-d4WKVv14cPymWA8JlyWuo3owvTSXqri1ACq5CTP1JEELNLWIwtg";
//        String model = "text-davinci-002-render-sha";
//        String prompt = "{\"action\":\"next\",\"messages\":[{\"id\":\"1c1d5427-49d6-45e7-947f-78fb267d99c9\",\"author\":{\"role\":\"user\"},\"content\":{\"content_type\":\"text\",\"parts\":[\"我挺累的\"]}}],\"parent_message_id\":\"719ec710-a483-4712-b4a6-e7a1362032a5\",\"model\":\"text-davinci-002-render-sha\",\"timezone_offset_min\":-480}";
//        String temperature = "0.5";
//        String maxTokens = "50";
//        String topP = "1";
//        String frequencyPenalty = "0";
//        String presencePenalty = "0";
//
//        OpenAIStreamAPI api = new OpenAIStreamAPI(apiKey, model, prompt, temperature, maxTokens, topP, frequencyPenalty, presencePenalty);
//        try {
//            api.start();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
